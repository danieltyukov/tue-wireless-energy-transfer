/*
 * maincontroller.h
 *
 *  Created on: May 30, 2024
 *      Author: Ben
 */

#ifndef INC_MAINCONTROLLER_H_
#define INC_MAINCONTROLLER_H_

void sysinit();

void setup();

void loop();

#endif /* INC_MAINCONTROLLER_H_ */
